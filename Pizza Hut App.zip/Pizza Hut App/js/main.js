showorder();
let addcustomerinput = document.getElementById("addcustomerinput");
let addorderbtn = document.getElementById("addorderbtn");

addorderbtn.addEventListener("click", function(){
    addcustomerinputval = addcustomerinput.value;
    
    if(addcustomerinputval.trim()!=0){
        let webtask = localStorage.getItem("localtask");
        if(webtask == null){
            taskObj = [];
        }
        else{
            taskObj = JSON.parse(webtask);
        }
        taskObj.push({'customer_name':addcustomerinputval, 'completeStatus':false});
        localStorage.setItem("localtask", JSON.stringify(taskObj));
        addcustomerinput.value = '';
    }
    showorder();
})

// showorder
function showorder(){
    let webtask = localStorage.getItem("localtask");
    if(webtask == null){
        taskObj = [];
    }
    else{
        taskObj = JSON.parse(webtask);
    }
    let html = '';
    let addedorderlist = document.getElementById("addedorderlist");
    taskObj.forEach((item, index) => {

        if(item.completeStatus==true){
            taskCompleteValue = `<td class="completed">${item.customer_name}</td>`;
        }else{
            taskCompleteValue = `<td>${item.customer_name}</td>`;
        }
        html += `<tr>
                    <th scope="row">${index+1}</th>
                    ${taskCompleteValue}
                    <td><button type="button" onclick="editorder(${index})" class="text-primary"><i class="fa fa-edit"></i>Edit</button></td>
                    <td><button type="button" class="text-success" id=${index}><i class="fa fa-check-square-o"></i>Complete</button></td>
                    <td><button type="button" onclick="deleteorder(${index})" class="text-danger"><i class="fa fa-trash"></i>Delete</button></td>
                </tr>`;
    });
    addedorderlist.innerHTML = html;
}

// editorder
function editorder(index){
    let saveindex = document.getElementById("saveindex");
    let addorderbtn = document.getElementById("addorderbtn");
    let saveorderbtn = document.getElementById("saveorderbtn");
    saveindex.value = index;
    let webtask = localStorage.getItem("localtask");
    let taskObj = JSON.parse(webtask); 
    
    addcustomerinput.value = taskObj[index]['customer_name'];
    addorderbtn.style.display="none";
    saveorderbtn.style.display="inline-block";
    deleteallbtn.style.marginLeft="0px";
    deleteallbtn.style.marginTop="29px";

}

// savetask
let saveorderbtn = document.getElementById("saveorderbtn");
saveorderbtn.addEventListener("click", function(){
    let addorderbtn = document.getElementById("addorderbtn");
    let webtask = localStorage.getItem("localtask");
    let taskObj = JSON.parse(webtask); 
    let saveindex = document.getElementById("saveindex").value;
    
    for (keys in taskObj[saveindex]) {
        if(keys == 'customer_name'){
            taskObj[saveindex].customer_name = addcustomerinput.value;
        }
      }
    saveorderbtn.style.display="none";
    addorderbtn.style.display="block";
    deleteallbtn.style.marginLeft="100px";
    deleteallbtn.style.marginTop="-56px";

    localStorage.setItem("localtask", JSON.stringify(taskObj));
    addcustomerinput.value='';
    showorder();
})

// deleteorder
function deleteorder(index){
    let webtask = localStorage.getItem("localtask");
    let taskObj = JSON.parse(webtask);
    taskObj.splice(index, 1);
    localStorage.setItem("localtask", JSON.stringify(taskObj));
    showorder();
}

// complete task
let addedorderlist = document.getElementById("addedorderlist");
addedorderlist.addEventListener("click", function(e){
        let webtask = localStorage.getItem("localtask");
        let taskObj = JSON.parse(webtask);
        
        let mytarget = e.target;
        if(mytarget.classList[0] === 'text-success'){
        let mytargetid = mytarget.getAttribute("id");
        
        
        
        mytargetpresibling = mytarget.parentElement.previousElementSibling.previousElementSibling;
            
            for (keys in taskObj[mytargetid]) {
                if(keys == 'completeStatus' && taskObj[mytargetid][keys]==true){
                    taskObj[mytargetid].completeStatus = false;
                }else if(keys == 'completeStatus' && taskObj[mytargetid][keys]==false){
                    taskObj[mytargetid].completeStatus = true;
                }
              }
        localStorage.setItem("localtask", JSON.stringify(taskObj));
        showorder();
    }
    })

    



// deleteall
let deleteallbtn = document.getElementById("deleteallbtn");
deleteallbtn.addEventListener("click", function(){
    let saveorderbtn = document.getElementById("saveorderbtn");
    let addorderbtn = document.getElementById("addorderbtn");
    let webtask = localStorage.getItem("localtask");
    let taskObj = JSON.parse(webtask);
    if(webtask == null){
        taskObj = [];
    }
    else{
        taskObj = JSON.parse(webtask);
        taskObj = [];
    }
    saveorderbtn.style.display="none";
    addorderbtn.style.display="block";
    deleteallbtn.style.marginLeft="100px";
    deleteallbtn.style.marginTop="-56px";
    localStorage.setItem("localtask", JSON.stringify(taskObj));
    showorder();

})














